//
//  GoopalPayObject.h
//  GoopalPaySDK
//
//  Created by marking on 16/7/21.
//  Copyright © 2016年 marking. All rights reserved.
//

#import <Foundation/Foundation.h>

#pragma mark ****** GoopalPayObject ******
/**
 第三方应用向果仁宝发送请求的基类
 */
@interface GoopalRequest : NSObject

/** 支付类型 01-app */
@property (nonatomic,copy) NSString * source;
/** 商户ID*/
@property (nonatomic,copy) NSString * appId;
/**  商户号  */
@property (nonatomic,copy) NSString * mercId;
/**  唯一识别码  */
@property (nonatomic,copy) NSString * singleNo;
/**  商户订单号  */
@property (nonatomic,copy) NSString * orderNo;
/**  消费订单号  */
@property (nonatomic,copy) NSString * gopOrderNo;
/**  订单日期  */
@property (nonatomic,copy) NSString * orderDate;
/**
 *  网页收银台 必传
 */
@property (nonatomic,copy) NSString * h5Url;



/**
 解析数据
 */
+(NSMutableDictionary *)dictWithModle:(GoopalRequest *)request;
@end




