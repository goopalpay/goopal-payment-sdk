//
//  GoopalPayApi.h
//  GoopalPaySDK
//
//  Created by marking on 16/7/21.
//  Copyright © 2016年 marking. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GoopalPayObject.h"
@interface GoopalPayApi : NSObject

/* 检查果仁宝是否已被用户安装
 *
 * @return 果仁宝已安装返回YES，未安装返回NO。
 */
+(BOOL) isGoopalInstalled;

/**
 *  打开果仁宝并且把字典格式的数据传递给果仁宝
 *
 *  @param dict 所传的参数
 *
 *  @return 成功Yes  失败No
 */

+(BOOL)sendRequst:(GoopalRequest *)request;
@end
